package Tuan10.Excersise2;

public class Animal implements CanMove {
    protected String name;


    @Override
    public void run() {

    }

    @Override
    public void back() {
    }

    @Override
    public void getVelocity() {

    }
}
