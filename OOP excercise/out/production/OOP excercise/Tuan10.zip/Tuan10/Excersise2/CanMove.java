package Tuan10.Excersise2;

public interface CanMove {
     void run();
     void back();
     void getVelocity();

}
