package Tuan10.Excersise2;

public interface CanEat {
    public void eat();
}
