package Tuan10.Excersise2;

public interface CanDrink   {

    public void drink();
}
