package Tuan10.Excersise2;

public class Cat extends Animal implements CanDrink,CanEat{
    protected String name;

    public String getName() {
        return name;
    }
    public void back() {
    }
    public void getVelocity() {

    }
    @Override
    public void drink() {

    }

    @Override
    public void eat() {

    }
}
